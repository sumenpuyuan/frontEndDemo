<?php
	
	class MySQLHelper{
		function execute_dql_fenye($fenye){
			
			$fenye->navigator="1  2 3";
		}
	}
?>