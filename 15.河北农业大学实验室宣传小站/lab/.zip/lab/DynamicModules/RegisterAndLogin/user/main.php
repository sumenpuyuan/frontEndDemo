<?php
	
	//require_once '../commonFuns.php';
	//userIsValid();
	session_start();
	echo "欢迎你".$_SESSION['loginuser'];
	echo "<a href="http://labpuyuan.nat123.net">实验室情况</a>
?>