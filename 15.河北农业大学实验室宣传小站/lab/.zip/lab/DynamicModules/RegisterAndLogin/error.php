<?php
header("content-type: text/html;charset=utf-8");
echo "对不起操作失败!";
?>