#!/bin/sh
touch agb