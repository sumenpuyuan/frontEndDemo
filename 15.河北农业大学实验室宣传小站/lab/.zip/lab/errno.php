<html>
<head>
	<meta charset="utf-8">
</head>
<style type="text/css">
	.by{
		float:right;
		margin-right:30%;
	}
</style>
<body style="background:#5C307D;font-family:微软雅黑">
<br><br><br><br><br><br><br><br><br><br>
<center>
	<h1>请使用pc访问。移动端正在开发</h1><p>
	
</center>
<div class="by">
<h3>by---sumenpuyuan</h3>
</div>
</body>
</html>